To run the application, run the following commands from the project folder:  

### `npm install`
### `npm start`